<script type="text/javascript">
alert('Url Not Found!');
window.history.back();
</script>
