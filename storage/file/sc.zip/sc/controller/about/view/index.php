<?php include 'include/header.php';  ?>
<main role="main">
        <div class="container">
          <div class="row">
            <h2> About</h2>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="card mb-12 box-shadow">
                <div class="card-body">
                  <p class="card-text"> Name : SC Framework </p>
                    <p class="card-text"> Version : 1.0 </p>
                    <p class="card-text"> Author : Saycode Development </p>
                    <p class="card-text"> Email : service@saycode.info </p>
                      <p class="card-text"> Phone : +66825915231 </p>
                  <!--div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                    </div>
                    <small class="text-muted">9 mins</small>
                  </div-->
                </div>
              </div>
            </div>
          </div>
        </div>
    </main>
<?php include 'include/footer.php';  ?>
