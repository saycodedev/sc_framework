
<div class="">
<br>  <hr width="80%">
</div>
<footer class="text-muted">
     <div class="container">
       <p class="float-right">
         <a href="#">On Top</a>
       </p>
    © 2018  - <?=date('Y')?> Copyright:  <a href="https://www.saycode.info" target="_blank">Saycode Dev</a>
     </div>
   </footer>
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  </body>
</html>
